/*****************************************************/

Redes de datos, Bases de datos II, Ingenieria de software I (rebain) 2021-08-01

Equipo 3.

Integrantes:

000404667 Johan Eduardo Cala Torra

000401676 Duvan Andres Diaz Montañez

000397866 Angela Sofia Remolina Gutierrez

…

Descripción:

Entrega de la propuesta para el desarrollo del proyecto integrador, las fuentes de la ampliación y condensado de fechas de Excel.

Archivos:

Propuesta-Equipo3.docx.

Proyecto-Condensado-Equipo3.xlsx

/*****************************************************/