module.exports = {
    database: {
        host: 'localhost',
        user: 'root',
        password: 'root',
        database: 'netby'
    }
};