/*****************************************************/

Redes de datos, Bases de datos II, Ingenieria de software I (rebain) 2021-10-25

Equipo 3.

Integrantes:

000404667 Johan Eduardo Cala Torra

000401676 Duvan Andres Diaz Montañez

000397866 Angela Sofia Remolina Gutierrez

…

Descripción:

Entrega del informe final del proyecto integrador. 
Nota 1: Vienen dos archivos principales InformeFinal-Equipo3.docx y InformeFinal-Equipo3.pdf. El PDF es para evitar cambios en el formato de word. 

Archivos:

Principales: 
- InformeFinal-Equipo3.docx
- InformeFinal-Equipo3.pdf

Anexo 1: DiagramaCasosDeUsoEq3.mdj 
Anexo 2: ActaDeRequerimientosEq3.docx
Anexo 3: EntidadRelacionEq3.png
Anexo 4: DiccionarioDatosEq3.html
Anexo 5: ModeloInterfazBajaFidelidad.pdf
Anexo 6: DiagramaDeBloques.jpg
Anexo 7: PoliticasRespaldoRecuperacionEq3.docx
Anexo 8: DiagramaArquitecturaEq3.png 
Anexo 9: ModeloSecuenciaEq3.mdj
Anexo 10: Topologia.png
Anexo 11: topologiaFisica.png
Anexo 12: Cumplimiento_Cronograma.xlsx
Anexo 13: https://youtu.be/vPwZfeDlWQc
Anexo 14: codigoEq3.zip
Anexo 15: https://github.com/angelasofiaremolinagutierrez/netby 



/*****************************************************/