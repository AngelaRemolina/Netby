/*****************************************************/

Redes de datos, Bases de datos II, Ingenieria de software I (rebain) 2021-08-01

Equipo 3.

Integrantes:

000404667 Johan Eduardo Cala Torra

000401676 Duvan Andres Diaz Montañez

000397866 Angela Sofia Remolina Gutierrez

…

Descripción:

Entrega del informe de avance del proyecto integrador. 
Nota 1: Vienen dos archivos principales InformeAvance1-Equipo3.docx y InformeAvance1-Equipo3.pdf. El PDF es para evitar cambios en el formato de word. 
Nota 2: Algunos de los campos del informe están vacios, porque solo se podrán llenar cuando el proyecto esté finalizado (discusión, trabajo futuro, agradecimientos)

Archivos:

Principales: 
- InformeAvance1-Equipo3.docx 
- InformeAvance1-Equipo3.pdf

Anexo 1: DiagramaCasosDeUsoEq3.mdj 
Anexo 2: ActaDeRequerimientosEq3.docx
Anexo 3: EntidadRelacionEq3.png
Anexo 4: DiccionarioDatosEq3.html
Anexo 5: Modelo_interfaz_de_baja_fidelidad.pdf
Anexo 6: DiagramaDeBloques.jpg


/*****************************************************/